﻿namespace MDIInventarioyFacturación.Forms.TrasladoTransporte
{
    partial class Agregar_Unidad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Agregar_Unidad));
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.lblresultadopiloto = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.lblnombre = new System.Windows.Forms.Label();
            this.lbldpi = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtbodegadestino = new System.Windows.Forms.TextBox();
            this.txtbodegaprocedencia = new System.Windows.Forms.TextBox();
            this.lblunidadseleccionada = new System.Windows.Forms.Label();
            this.lblUnidad = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Label5 = new System.Windows.Forms.Label();
            this.Lblcapacidad = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtobservaciones = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_actualizar = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.btn_imprimir = new System.Windows.Forms.Button();
            this.btn_atras = new System.Windows.Forms.Button();
            this.btn_adelante = new System.Windows.Forms.Button();
            this.btn_primero = new System.Windows.Forms.Button();
            this.btn_ultimo = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblCant = new System.Windows.Forms.Label();
            this.lblprod = new System.Windows.Forms.Label();
            this.cn1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblNomov = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.lblresultadopiloto);
            this.GroupBox2.Controls.Add(this.button3);
            this.GroupBox2.Controls.Add(this.lblnombre);
            this.GroupBox2.Controls.Add(this.lbldpi);
            this.GroupBox2.Controls.Add(this.Label7);
            this.GroupBox2.Controls.Add(this.Label6);
            this.GroupBox2.Location = new System.Drawing.Point(65, 419);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(534, 114);
            this.GroupBox2.TabIndex = 6;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Ingresar Piloto";
            // 
            // lblresultadopiloto
            // 
            this.lblresultadopiloto.AutoSize = true;
            this.lblresultadopiloto.Location = new System.Drawing.Point(31, 90);
            this.lblresultadopiloto.Name = "lblresultadopiloto";
            this.lblresultadopiloto.Size = new System.Drawing.Size(41, 13);
            this.lblresultadopiloto.TabIndex = 8;
            this.lblresultadopiloto.Text = "label10";
            this.lblresultadopiloto.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(444, 82);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "Buscar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lblnombre
            // 
            this.lblnombre.AutoSize = true;
            this.lblnombre.Location = new System.Drawing.Point(63, 60);
            this.lblnombre.Name = "lblnombre";
            this.lblnombre.Size = new System.Drawing.Size(0, 13);
            this.lblnombre.TabIndex = 5;
            // 
            // lbldpi
            // 
            this.lbldpi.AutoSize = true;
            this.lbldpi.Location = new System.Drawing.Point(47, 27);
            this.lbldpi.Name = "lbldpi";
            this.lbldpi.Size = new System.Drawing.Size(0, 13);
            this.lbldpi.TabIndex = 4;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(13, 60);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(44, 13);
            this.Label7.TabIndex = 3;
            this.Label7.Text = "Nombre";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(13, 27);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(28, 13);
            this.Label6.TabIndex = 0;
            this.Label6.Text = "DPI ";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.txtbodegadestino);
            this.GroupBox1.Controls.Add(this.txtbodegaprocedencia);
            this.GroupBox1.Controls.Add(this.lblunidadseleccionada);
            this.GroupBox1.Controls.Add(this.lblUnidad);
            this.GroupBox1.Controls.Add(this.label4);
            this.GroupBox1.Controls.Add(this.label1);
            this.GroupBox1.Controls.Add(this.dataGridView1);
            this.GroupBox1.Controls.Add(this.textBox4);
            this.GroupBox1.Controls.Add(this.Label9);
            this.GroupBox1.Controls.Add(this.Label8);
            this.GroupBox1.Controls.Add(this.DateTimePicker1);
            this.GroupBox1.Controls.Add(this.Label5);
            this.GroupBox1.Controls.Add(this.Lblcapacidad);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Location = new System.Drawing.Point(61, 177);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(536, 236);
            this.GroupBox1.TabIndex = 1;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Favor Ingresar Datos de Unidad de Transporte";
            this.GroupBox1.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // txtbodegadestino
            // 
            this.txtbodegadestino.Location = new System.Drawing.Point(381, 204);
            this.txtbodegadestino.Name = "txtbodegadestino";
            this.txtbodegadestino.Size = new System.Drawing.Size(126, 20);
            this.txtbodegadestino.TabIndex = 17;
            // 
            // txtbodegaprocedencia
            // 
            this.txtbodegaprocedencia.Location = new System.Drawing.Point(138, 205);
            this.txtbodegaprocedencia.Name = "txtbodegaprocedencia";
            this.txtbodegaprocedencia.Size = new System.Drawing.Size(126, 20);
            this.txtbodegaprocedencia.TabIndex = 16;
            // 
            // lblunidadseleccionada
            // 
            this.lblunidadseleccionada.AutoSize = true;
            this.lblunidadseleccionada.Location = new System.Drawing.Point(285, 21);
            this.lblunidadseleccionada.Name = "lblunidadseleccionada";
            this.lblunidadseleccionada.Size = new System.Drawing.Size(41, 13);
            this.lblunidadseleccionada.TabIndex = 15;
            this.lblunidadseleccionada.Text = "label10";
            this.lblunidadseleccionada.Visible = false;
            // 
            // lblUnidad
            // 
            this.lblUnidad.AutoSize = true;
            this.lblUnidad.Location = new System.Drawing.Point(445, 21);
            this.lblUnidad.Name = "lblUnidad";
            this.lblUnidad.Size = new System.Drawing.Size(0, 13);
            this.lblUnidad.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(332, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Unidad seleccionada";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Ingrese Placa";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(18, 44);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(505, 77);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(92, 18);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(129, 20);
            this.textBox4.TabIndex = 2;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(295, 208);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(83, 13);
            this.Label9.TabIndex = 9;
            this.Label9.Text = "Bodega Destino";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(26, 208);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(107, 13);
            this.Label8.TabIndex = 7;
            this.Label8.Text = "Bodega Procedencia";
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.Location = new System.Drawing.Point(167, 162);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.DateTimePicker1.TabIndex = 3;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(166, 138);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(57, 13);
            this.Label5.TabIndex = 5;
            this.Label5.Text = "Toneladas";
            // 
            // Lblcapacidad
            // 
            this.Lblcapacidad.AutoSize = true;
            this.Lblcapacidad.Location = new System.Drawing.Point(121, 138);
            this.Lblcapacidad.Name = "Lblcapacidad";
            this.Lblcapacidad.Size = new System.Drawing.Size(0, 13);
            this.Lblcapacidad.TabIndex = 4;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(15, 168);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(145, 13);
            this.Label3.TabIndex = 3;
            this.Label3.Text = "Fecha Prevista de Operacion";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(17, 138);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(98, 13);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Capacidad camion ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtobservaciones);
            this.groupBox3.Location = new System.Drawing.Point(72, 540);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(526, 111);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Obserbaciones";
            // 
            // txtobservaciones
            // 
            this.txtobservaciones.Location = new System.Drawing.Point(6, 19);
            this.txtobservaciones.Multiline = true;
            this.txtobservaciones.Name = "txtobservaciones";
            this.txtobservaciones.Size = new System.Drawing.Size(514, 86);
            this.txtobservaciones.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btn_insertar);
            this.flowLayoutPanel1.Controls.Add(this.btn_modificar);
            this.flowLayoutPanel1.Controls.Add(this.btn_eliminar);
            this.flowLayoutPanel1.Controls.Add(this.btn_actualizar);
            this.flowLayoutPanel1.Controls.Add(this.button5);
            this.flowLayoutPanel1.Controls.Add(this.btn_guardar);
            this.flowLayoutPanel1.Controls.Add(this.btn_imprimir);
            this.flowLayoutPanel1.Controls.Add(this.btn_atras);
            this.flowLayoutPanel1.Controls.Add(this.btn_adelante);
            this.flowLayoutPanel1.Controls.Add(this.btn_primero);
            this.flowLayoutPanel1.Controls.Add(this.btn_ultimo);
            this.flowLayoutPanel1.Controls.Add(this.button12);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(44, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(555, 48);
            this.flowLayoutPanel1.TabIndex = 12;
            // 
            // btn_insertar
            // 
            this.btn_insertar.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_insertar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_insertar.Enabled = false;
            this.btn_insertar.Image = ((System.Drawing.Image)(resources.GetObject("btn_insertar.Image")));
            this.btn_insertar.Location = new System.Drawing.Point(3, 3);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(40, 40);
            this.btn_insertar.TabIndex = 13;
            this.btn_insertar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_insertar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btn_insertar.UseVisualStyleBackColor = false;
            // 
            // btn_modificar
            // 
            this.btn_modificar.Enabled = false;
            this.btn_modificar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_modificar.Image = ((System.Drawing.Image)(resources.GetObject("btn_modificar.Image")));
            this.btn_modificar.Location = new System.Drawing.Point(49, 3);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(40, 40);
            this.btn_modificar.TabIndex = 12;
            this.btn_modificar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_modificar.UseVisualStyleBackColor = true;
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Image = ((System.Drawing.Image)(resources.GetObject("btn_eliminar.Image")));
            this.btn_eliminar.Location = new System.Drawing.Point(95, 3);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(40, 40);
            this.btn_eliminar.TabIndex = 11;
            this.btn_eliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // btn_actualizar
            // 
            this.btn_actualizar.Enabled = false;
            this.btn_actualizar.Image = ((System.Drawing.Image)(resources.GetObject("btn_actualizar.Image")));
            this.btn_actualizar.Location = new System.Drawing.Point(141, 3);
            this.btn_actualizar.Name = "btn_actualizar";
            this.btn_actualizar.Size = new System.Drawing.Size(40, 40);
            this.btn_actualizar.TabIndex = 10;
            this.btn_actualizar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_actualizar.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(187, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 40);
            this.button5.TabIndex = 9;
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // btn_guardar
            // 
            this.btn_guardar.Image = ((System.Drawing.Image)(resources.GetObject("btn_guardar.Image")));
            this.btn_guardar.Location = new System.Drawing.Point(233, 3);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(40, 40);
            this.btn_guardar.TabIndex = 8;
            this.btn_guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // btn_imprimir
            // 
            this.btn_imprimir.Enabled = false;
            this.btn_imprimir.Image = ((System.Drawing.Image)(resources.GetObject("btn_imprimir.Image")));
            this.btn_imprimir.Location = new System.Drawing.Point(279, 3);
            this.btn_imprimir.Name = "btn_imprimir";
            this.btn_imprimir.Size = new System.Drawing.Size(40, 40);
            this.btn_imprimir.TabIndex = 7;
            this.btn_imprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_imprimir.UseVisualStyleBackColor = true;
            // 
            // btn_atras
            // 
            this.btn_atras.Image = ((System.Drawing.Image)(resources.GetObject("btn_atras.Image")));
            this.btn_atras.Location = new System.Drawing.Point(325, 3);
            this.btn_atras.Name = "btn_atras";
            this.btn_atras.Size = new System.Drawing.Size(41, 40);
            this.btn_atras.TabIndex = 6;
            this.btn_atras.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_atras.UseVisualStyleBackColor = true;
            this.btn_atras.Click += new System.EventHandler(this.btn_atras_Click);
            // 
            // btn_adelante
            // 
            this.btn_adelante.Enabled = false;
            this.btn_adelante.Image = ((System.Drawing.Image)(resources.GetObject("btn_adelante.Image")));
            this.btn_adelante.Location = new System.Drawing.Point(372, 3);
            this.btn_adelante.Name = "btn_adelante";
            this.btn_adelante.Size = new System.Drawing.Size(41, 40);
            this.btn_adelante.TabIndex = 3;
            this.btn_adelante.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_adelante.UseVisualStyleBackColor = true;
            // 
            // btn_primero
            // 
            this.btn_primero.Enabled = false;
            this.btn_primero.Image = ((System.Drawing.Image)(resources.GetObject("btn_primero.Image")));
            this.btn_primero.Location = new System.Drawing.Point(419, 3);
            this.btn_primero.Name = "btn_primero";
            this.btn_primero.Size = new System.Drawing.Size(40, 40);
            this.btn_primero.TabIndex = 5;
            this.btn_primero.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_primero.UseVisualStyleBackColor = true;
            // 
            // btn_ultimo
            // 
            this.btn_ultimo.Enabled = false;
            this.btn_ultimo.Image = ((System.Drawing.Image)(resources.GetObject("btn_ultimo.Image")));
            this.btn_ultimo.Location = new System.Drawing.Point(465, 3);
            this.btn_ultimo.Name = "btn_ultimo";
            this.btn_ultimo.Size = new System.Drawing.Size(40, 40);
            this.btn_ultimo.TabIndex = 4;
            this.btn_ultimo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_ultimo.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
            this.button12.Location = new System.Drawing.Point(511, 3);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(40, 40);
            this.button12.TabIndex = 14;
            this.button12.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblCant);
            this.groupBox4.Controls.Add(this.lblprod);
            this.groupBox4.Controls.Add(this.cn1);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.lblNomov);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Location = new System.Drawing.Point(61, 56);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(531, 115);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Transaccion";
            // 
            // lblCant
            // 
            this.lblCant.AutoSize = true;
            this.lblCant.Location = new System.Drawing.Point(326, 32);
            this.lblCant.Name = "lblCant";
            this.lblCant.Size = new System.Drawing.Size(0, 13);
            this.lblCant.TabIndex = 14;
            // 
            // lblprod
            // 
            this.lblprod.AutoSize = true;
            this.lblprod.Location = new System.Drawing.Point(89, 71);
            this.lblprod.Name = "lblprod";
            this.lblprod.Size = new System.Drawing.Size(0, 13);
            this.lblprod.TabIndex = 13;
            // 
            // cn1
            // 
            this.cn1.AutoSize = true;
            this.cn1.Location = new System.Drawing.Point(274, 32);
            this.cn1.Name = "cn1";
            this.cn1.Size = new System.Drawing.Size(49, 13);
            this.cn1.TabIndex = 12;
            this.cn1.Text = "Cantidad";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(35, 71);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Producto";
            // 
            // lblNomov
            // 
            this.lblNomov.AutoSize = true;
            this.lblNomov.Location = new System.Drawing.Point(112, 29);
            this.lblNomov.Name = "lblNomov";
            this.lblNomov.Size = new System.Drawing.Size(0, 13);
            this.lblNomov.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "No. Movimiento";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(450, 86);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Agregar_Unidad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(692, 656);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.GroupBox1);
            this.Name = "Agregar_Unidad";
            this.Text = "Agregar_Unidad";
            this.Load += new System.EventHandler(this.Agregar_Unidad_Load);
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.DateTimePicker DateTimePicker1;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Lblcapacidad;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lblnombre;
        private System.Windows.Forms.Label lbldpi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lblUnidad;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblresultadopiloto;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtobservaciones;
        private System.Windows.Forms.Label lblunidadseleccionada;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btn_imprimir;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button btn_adelante;
        private System.Windows.Forms.Button btn_ultimo;
        private System.Windows.Forms.Button btn_primero;
        private System.Windows.Forms.Button btn_atras;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btn_actualizar;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtbodegadestino;
        private System.Windows.Forms.TextBox txtbodegaprocedencia;
        private System.Windows.Forms.Label lblNomov;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblCant;
        private System.Windows.Forms.Label lblprod;
        private System.Windows.Forms.Label cn1;
        private System.Windows.Forms.Label label11;
    }
}