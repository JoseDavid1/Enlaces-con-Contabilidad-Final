﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Data.Odbc;

namespace MDIInventarioyFacturación
{
    public partial class Poliza : Form
    {
        public Poliza()
        {
            InitializeComponent();
        }

        private void Poliza_Load(object sender, EventArgs e)
        {

        }

        private void Añadir_Click(object sender, EventArgs e)
        {
            //objetos del tipo de la clase referencia
            MyDBEntity mdb = new MyDBEntity();
            //variable para almacenar la consulta sql
            string sql = "INSERT INTO polizainventario VALUES('" + idpoliza.Text + "','" + periodo.Text + "','" + fechainicial.Value.ToString("yyyy-MM-dd") + "','" + fechafinal.Value.ToString("yyyy-MM-dd") + "','" + concepto.Text + "', '" + fechapoliza.Value.ToString("yyyy-MM-dd") + "','" + transaccion.Text + "');";

            try
            {
                //se manda como parametro el string con la consulta 
                mdb.EjecutarSQL(sql);
                MessageBox.Show("Transacción ingresada a póliza");

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            Transacciones trans = new Transacciones();
            trans.ShowDialog();
            transaccion.Text = Program.idtransaccion.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reporte rep = new Reporte();
            rep.Show();
        }
    }
}
