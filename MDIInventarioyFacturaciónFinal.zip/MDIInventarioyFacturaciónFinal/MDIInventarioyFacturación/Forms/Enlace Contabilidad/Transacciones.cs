﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Data.Odbc;

namespace MDIInventarioyFacturación
{
    public partial class Transacciones : Form
    {
        public Transacciones()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Program.idtransaccion = Int32.Parse(dgvtransacciones.CurrentRow.Cells[0].Value.ToString());
        }

        private void Transacciones_Load(object sender, EventArgs e)
        {
            MyDBEntity mdb = new MyDBEntity();
            string sql = "select idTransaccionesInventario, nombre, fechaTransaccion from transaccionesinventario;";
            DataTable tbl = new DataTable();

            try
            {

                tbl = mdb.CargarTabla(sql);
                //ctacodigo.ValueMember = "nombre";
                //ctacodigo.DisplayMember = "idcuenta";
                //ctacodigo.DataSource = tbl;
                //txtcuenta.Text = ctacodigo.Text;


                //llama al método de la clase para conectar
                MyDBEntity mienty = new MyDBEntity();
                mienty.conectar();

                OdbcCommand cmd = new OdbcCommand(sql, mienty.conexion);
                OdbcDataAdapter da = new OdbcDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvtransacciones.DataSource = dt;


            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR: " + ex.Message);
            }
        }
    }
}
