﻿namespace MDIInventarioyFacturación.Forms.ListPrecios
{
    partial class actualizarPorcentajes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.Txtx_Porc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Txtx_Desc = new System.Windows.Forms.TextBox();
            this.Txtx_min = new System.Windows.Forms.TextBox();
            this.lbl_mayorista = new System.Windows.Forms.Label();
            this.lbl_minorista = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "Crear nueva Lista";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(282, 106);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(399, 150);
            this.dataGridView1.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "Porcentaje";
            // 
            // Txtx_Porc
            // 
            this.Txtx_Porc.Location = new System.Drawing.Point(102, 151);
            this.Txtx_Porc.Name = "Txtx_Porc";
            this.Txtx_Porc.Size = new System.Drawing.Size(100, 20);
            this.Txtx_Porc.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 303);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Cod: 2420";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(102, 262);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(109, 23);
            this.button3.TabIndex = 27;
            this.button3.Text = "Probar conexion";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(219, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 24);
            this.label2.TabIndex = 26;
            this.label2.Text = "Manejo Listas de precios";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(102, 177);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 23);
            this.button2.TabIndex = 25;
            this.button2.Text = "Guardar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(102, 233);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Actualizar Tabla";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Txtx_Desc
            // 
            this.Txtx_Desc.Location = new System.Drawing.Point(102, 125);
            this.Txtx_Desc.Name = "Txtx_Desc";
            this.Txtx_Desc.Size = new System.Drawing.Size(100, 20);
            this.Txtx_Desc.TabIndex = 23;
            // 
            // Txtx_min
            // 
            this.Txtx_min.Enabled = false;
            this.Txtx_min.Location = new System.Drawing.Point(102, 99);
            this.Txtx_min.Name = "Txtx_min";
            this.Txtx_min.Size = new System.Drawing.Size(100, 20);
            this.Txtx_min.TabIndex = 22;
            // 
            // lbl_mayorista
            // 
            this.lbl_mayorista.AutoSize = true;
            this.lbl_mayorista.Location = new System.Drawing.Point(28, 132);
            this.lbl_mayorista.Name = "lbl_mayorista";
            this.lbl_mayorista.Size = new System.Drawing.Size(63, 13);
            this.lbl_mayorista.TabIndex = 21;
            this.lbl_mayorista.Text = "Descripcion";
            // 
            // lbl_minorista
            // 
            this.lbl_minorista.AutoSize = true;
            this.lbl_minorista.Location = new System.Drawing.Point(33, 106);
            this.lbl_minorista.Name = "lbl_minorista";
            this.lbl_minorista.Size = new System.Drawing.Size(38, 13);
            this.lbl_minorista.TabIndex = 20;
            this.lbl_minorista.Text = "IdLista";
            // 
            // actualizarPorcentajes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(707, 328);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Txtx_Porc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Txtx_Desc);
            this.Controls.Add(this.Txtx_min);
            this.Controls.Add(this.lbl_mayorista);
            this.Controls.Add(this.lbl_minorista);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "actualizarPorcentajes";
            this.Text = "actualizarPorcentajes";
            this.Load += new System.EventHandler(this.actualizarPorcentajes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Txtx_Porc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Txtx_Desc;
        private System.Windows.Forms.TextBox Txtx_min;
        private System.Windows.Forms.Label lbl_mayorista;
        private System.Windows.Forms.Label lbl_minorista;
    }
}