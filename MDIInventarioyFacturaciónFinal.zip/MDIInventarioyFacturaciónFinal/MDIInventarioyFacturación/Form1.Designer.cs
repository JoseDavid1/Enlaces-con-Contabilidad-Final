﻿namespace MDIInventarioyFacturación
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hotelería1000ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaccionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaccionalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.procesosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enlaceConContabilidadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inventarioYFacturación2000ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catálogoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoDePreciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaccionalToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.entradasYSalidaInventarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trasladoEntreBodegasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoEnvioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mantenimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pilotoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unidadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.actualizarListasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.procesosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.enlaceConContabilidadToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.comisionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nóminas3000ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catálogosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaccionalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.procesosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.contabilidad4000ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catálogosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.transaccionalesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.procesosToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.enlaceConContabilidadToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bancos5000ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catálogosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.transaccionalToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.procesosToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.enlaceConContabilidadToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.cxCCxPComprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catálogosToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.transaccionalesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.procesosToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.enlaceConContabilidadToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.cotizacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pedidoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facturacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hotelería1000ToolStripMenuItem,
            this.inventarioYFacturación2000ToolStripMenuItem,
            this.nóminas3000ToolStripMenuItem,
            this.contabilidad4000ToolStripMenuItem,
            this.bancos5000ToolStripMenuItem,
            this.cxCCxPComprasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1108, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hotelería1000ToolStripMenuItem
            // 
            this.hotelería1000ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.transaccionalToolStripMenuItem,
            this.transaccionalToolStripMenuItem1,
            this.reportesToolStripMenuItem,
            this.procesosToolStripMenuItem});
            this.hotelería1000ToolStripMenuItem.Name = "hotelería1000ToolStripMenuItem";
            this.hotelería1000ToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.hotelería1000ToolStripMenuItem.Text = "Hotelería (1000)";
            // 
            // transaccionalToolStripMenuItem
            // 
            this.transaccionalToolStripMenuItem.Name = "transaccionalToolStripMenuItem";
            this.transaccionalToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.transaccionalToolStripMenuItem.Text = "Catálogos";
            // 
            // transaccionalToolStripMenuItem1
            // 
            this.transaccionalToolStripMenuItem1.Name = "transaccionalToolStripMenuItem1";
            this.transaccionalToolStripMenuItem1.Size = new System.Drawing.Size(187, 26);
            this.transaccionalToolStripMenuItem1.Text = "Transaccionales";
            // 
            // reportesToolStripMenuItem
            // 
            this.reportesToolStripMenuItem.Name = "reportesToolStripMenuItem";
            this.reportesToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.reportesToolStripMenuItem.Text = "Reportes";
            // 
            // procesosToolStripMenuItem
            // 
            this.procesosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enlaceConContabilidadToolStripMenuItem});
            this.procesosToolStripMenuItem.Name = "procesosToolStripMenuItem";
            this.procesosToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.procesosToolStripMenuItem.Text = "Procesos";
            // 
            // enlaceConContabilidadToolStripMenuItem
            // 
            this.enlaceConContabilidadToolStripMenuItem.Name = "enlaceConContabilidadToolStripMenuItem";
            this.enlaceConContabilidadToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.enlaceConContabilidadToolStripMenuItem.Text = "Enlace con Contabilidad";
            // 
            // inventarioYFacturación2000ToolStripMenuItem
            // 
            this.inventarioYFacturación2000ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catálogoToolStripMenuItem,
            this.transaccionalToolStripMenuItem2,
            this.reportesToolStripMenuItem1,
            this.procesosToolStripMenuItem1,
            this.comisionesToolStripMenuItem});
            this.inventarioYFacturación2000ToolStripMenuItem.Name = "inventarioYFacturación2000ToolStripMenuItem";
            this.inventarioYFacturación2000ToolStripMenuItem.Size = new System.Drawing.Size(223, 24);
            this.inventarioYFacturación2000ToolStripMenuItem.Text = "Inventario y Facturación (2000)";
            // 
            // catálogoToolStripMenuItem
            // 
            this.catálogoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listadoDePreciosToolStripMenuItem,
            this.cotizacionToolStripMenuItem,
            this.pedidoToolStripMenuItem,
            this.facturacionToolStripMenuItem});
            this.catálogoToolStripMenuItem.Name = "catálogoToolStripMenuItem";
            this.catálogoToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.catálogoToolStripMenuItem.Text = "Catálogo";
            // 
            // listadoDePreciosToolStripMenuItem
            // 
            this.listadoDePreciosToolStripMenuItem.Name = "listadoDePreciosToolStripMenuItem";
            this.listadoDePreciosToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.listadoDePreciosToolStripMenuItem.Text = "Listado de Precios";
            this.listadoDePreciosToolStripMenuItem.Click += new System.EventHandler(this.listadoDePreciosToolStripMenuItem_Click);
            // 
            // transaccionalToolStripMenuItem2
            // 
            this.transaccionalToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.entradasYSalidaInventarioToolStripMenuItem,
            this.trasladoEntreBodegasToolStripMenuItem,
            this.actualizarListasToolStripMenuItem});
            this.transaccionalToolStripMenuItem2.Name = "transaccionalToolStripMenuItem2";
            this.transaccionalToolStripMenuItem2.Size = new System.Drawing.Size(187, 26);
            this.transaccionalToolStripMenuItem2.Text = "Transaccionales";
            // 
            // entradasYSalidaInventarioToolStripMenuItem
            // 
            this.entradasYSalidaInventarioToolStripMenuItem.Name = "entradasYSalidaInventarioToolStripMenuItem";
            this.entradasYSalidaInventarioToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.entradasYSalidaInventarioToolStripMenuItem.Text = "Entradas y Salida Inventario";
            this.entradasYSalidaInventarioToolStripMenuItem.Click += new System.EventHandler(this.entradasYSalidaInventarioToolStripMenuItem_Click);
            // 
            // trasladoEntreBodegasToolStripMenuItem
            // 
            this.trasladoEntreBodegasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoEnvioToolStripMenuItem,
            this.mantenimientoToolStripMenuItem});
            this.trasladoEntreBodegasToolStripMenuItem.Name = "trasladoEntreBodegasToolStripMenuItem";
            this.trasladoEntreBodegasToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.trasladoEntreBodegasToolStripMenuItem.Text = "Traslado entre Bodegas";
            this.trasladoEntreBodegasToolStripMenuItem.Click += new System.EventHandler(this.trasladoEntreBodegasToolStripMenuItem_Click);
            // 
            // nuevoEnvioToolStripMenuItem
            // 
            this.nuevoEnvioToolStripMenuItem.Name = "nuevoEnvioToolStripMenuItem";
            this.nuevoEnvioToolStripMenuItem.Size = new System.Drawing.Size(185, 26);
            this.nuevoEnvioToolStripMenuItem.Text = "Nuevo Envio";
            this.nuevoEnvioToolStripMenuItem.Click += new System.EventHandler(this.nuevoEnvioToolStripMenuItem_Click);
            // 
            // mantenimientoToolStripMenuItem
            // 
            this.mantenimientoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pilotoToolStripMenuItem,
            this.unidadToolStripMenuItem});
            this.mantenimientoToolStripMenuItem.Name = "mantenimientoToolStripMenuItem";
            this.mantenimientoToolStripMenuItem.Size = new System.Drawing.Size(185, 26);
            this.mantenimientoToolStripMenuItem.Text = "Mantenimiento";
            // 
            // pilotoToolStripMenuItem
            // 
            this.pilotoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agregarToolStripMenuItem,
            this.editarToolStripMenuItem});
            this.pilotoToolStripMenuItem.Name = "pilotoToolStripMenuItem";
            this.pilotoToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.pilotoToolStripMenuItem.Text = "Piloto";
            // 
            // agregarToolStripMenuItem
            // 
            this.agregarToolStripMenuItem.Name = "agregarToolStripMenuItem";
            this.agregarToolStripMenuItem.Size = new System.Drawing.Size(138, 26);
            this.agregarToolStripMenuItem.Text = "Agregar";
            this.agregarToolStripMenuItem.Click += new System.EventHandler(this.agregarToolStripMenuItem_Click);
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(138, 26);
            this.editarToolStripMenuItem.Text = "Editar";
            this.editarToolStripMenuItem.Click += new System.EventHandler(this.editarToolStripMenuItem_Click);
            // 
            // unidadToolStripMenuItem
            // 
            this.unidadToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agregarToolStripMenuItem1,
            this.editarToolStripMenuItem1});
            this.unidadToolStripMenuItem.Name = "unidadToolStripMenuItem";
            this.unidadToolStripMenuItem.Size = new System.Drawing.Size(132, 26);
            this.unidadToolStripMenuItem.Text = "Unidad";
            // 
            // agregarToolStripMenuItem1
            // 
            this.agregarToolStripMenuItem1.Name = "agregarToolStripMenuItem1";
            this.agregarToolStripMenuItem1.Size = new System.Drawing.Size(138, 26);
            this.agregarToolStripMenuItem1.Text = "Agregar";
            this.agregarToolStripMenuItem1.Click += new System.EventHandler(this.agregarToolStripMenuItem1_Click);
            // 
            // editarToolStripMenuItem1
            // 
            this.editarToolStripMenuItem1.Name = "editarToolStripMenuItem1";
            this.editarToolStripMenuItem1.Size = new System.Drawing.Size(138, 26);
            this.editarToolStripMenuItem1.Text = "Editar";
            this.editarToolStripMenuItem1.Click += new System.EventHandler(this.editarToolStripMenuItem1_Click);
            // 
            // actualizarListasToolStripMenuItem
            // 
            this.actualizarListasToolStripMenuItem.Name = "actualizarListasToolStripMenuItem";
            this.actualizarListasToolStripMenuItem.Size = new System.Drawing.Size(267, 26);
            this.actualizarListasToolStripMenuItem.Text = "Actualizar Listas";
            this.actualizarListasToolStripMenuItem.Click += new System.EventHandler(this.actualizarListasToolStripMenuItem_Click);
            // 
            // reportesToolStripMenuItem1
            // 
            this.reportesToolStripMenuItem1.Name = "reportesToolStripMenuItem1";
            this.reportesToolStripMenuItem1.Size = new System.Drawing.Size(187, 26);
            this.reportesToolStripMenuItem1.Text = "Reportes";
            // 
            // procesosToolStripMenuItem1
            // 
            this.procesosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enlaceConContabilidadToolStripMenuItem1});
            this.procesosToolStripMenuItem1.Name = "procesosToolStripMenuItem1";
            this.procesosToolStripMenuItem1.Size = new System.Drawing.Size(187, 26);
            this.procesosToolStripMenuItem1.Text = "Procesos";
            // 
            // enlaceConContabilidadToolStripMenuItem1
            // 
            this.enlaceConContabilidadToolStripMenuItem1.Name = "enlaceConContabilidadToolStripMenuItem1";
            this.enlaceConContabilidadToolStripMenuItem1.Size = new System.Drawing.Size(245, 26);
            this.enlaceConContabilidadToolStripMenuItem1.Text = "Enlace con Contabilidad";
            this.enlaceConContabilidadToolStripMenuItem1.Click += new System.EventHandler(this.enlaceConContabilidadToolStripMenuItem1_Click);
            // 
            // comisionesToolStripMenuItem
            // 
            this.comisionesToolStripMenuItem.Name = "comisionesToolStripMenuItem";
            this.comisionesToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.comisionesToolStripMenuItem.Text = "Comisiones";
            this.comisionesToolStripMenuItem.Click += new System.EventHandler(this.comisionesToolStripMenuItem_Click);
            // 
            // nóminas3000ToolStripMenuItem
            // 
            this.nóminas3000ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catálogosToolStripMenuItem,
            this.transaccionalesToolStripMenuItem,
            this.reportesToolStripMenuItem2,
            this.procesosToolStripMenuItem2});
            this.nóminas3000ToolStripMenuItem.Name = "nóminas3000ToolStripMenuItem";
            this.nóminas3000ToolStripMenuItem.Size = new System.Drawing.Size(126, 24);
            this.nóminas3000ToolStripMenuItem.Text = "Nóminas (3000)";
            // 
            // catálogosToolStripMenuItem
            // 
            this.catálogosToolStripMenuItem.Name = "catálogosToolStripMenuItem";
            this.catálogosToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.catálogosToolStripMenuItem.Text = "Catálogos";
            // 
            // transaccionalesToolStripMenuItem
            // 
            this.transaccionalesToolStripMenuItem.Name = "transaccionalesToolStripMenuItem";
            this.transaccionalesToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.transaccionalesToolStripMenuItem.Text = "Transaccionales";
            // 
            // reportesToolStripMenuItem2
            // 
            this.reportesToolStripMenuItem2.Name = "reportesToolStripMenuItem2";
            this.reportesToolStripMenuItem2.Size = new System.Drawing.Size(187, 26);
            this.reportesToolStripMenuItem2.Text = "Reportes";
            // 
            // procesosToolStripMenuItem2
            // 
            this.procesosToolStripMenuItem2.Name = "procesosToolStripMenuItem2";
            this.procesosToolStripMenuItem2.Size = new System.Drawing.Size(187, 26);
            this.procesosToolStripMenuItem2.Text = "Procesos";
            // 
            // contabilidad4000ToolStripMenuItem
            // 
            this.contabilidad4000ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catálogosToolStripMenuItem1,
            this.transaccionalesToolStripMenuItem1,
            this.reportesToolStripMenuItem3,
            this.procesosToolStripMenuItem3});
            this.contabilidad4000ToolStripMenuItem.Name = "contabilidad4000ToolStripMenuItem";
            this.contabilidad4000ToolStripMenuItem.Size = new System.Drawing.Size(153, 24);
            this.contabilidad4000ToolStripMenuItem.Text = "Contabilidad (4000)";
            // 
            // catálogosToolStripMenuItem1
            // 
            this.catálogosToolStripMenuItem1.Name = "catálogosToolStripMenuItem1";
            this.catálogosToolStripMenuItem1.Size = new System.Drawing.Size(187, 26);
            this.catálogosToolStripMenuItem1.Text = "Catálogos";
            // 
            // transaccionalesToolStripMenuItem1
            // 
            this.transaccionalesToolStripMenuItem1.Name = "transaccionalesToolStripMenuItem1";
            this.transaccionalesToolStripMenuItem1.Size = new System.Drawing.Size(187, 26);
            this.transaccionalesToolStripMenuItem1.Text = "Transaccionales";
            // 
            // reportesToolStripMenuItem3
            // 
            this.reportesToolStripMenuItem3.Name = "reportesToolStripMenuItem3";
            this.reportesToolStripMenuItem3.Size = new System.Drawing.Size(187, 26);
            this.reportesToolStripMenuItem3.Text = "Reportes";
            // 
            // procesosToolStripMenuItem3
            // 
            this.procesosToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enlaceConContabilidadToolStripMenuItem2});
            this.procesosToolStripMenuItem3.Name = "procesosToolStripMenuItem3";
            this.procesosToolStripMenuItem3.Size = new System.Drawing.Size(187, 26);
            this.procesosToolStripMenuItem3.Text = "Procesos";
            // 
            // enlaceConContabilidadToolStripMenuItem2
            // 
            this.enlaceConContabilidadToolStripMenuItem2.Name = "enlaceConContabilidadToolStripMenuItem2";
            this.enlaceConContabilidadToolStripMenuItem2.Size = new System.Drawing.Size(245, 26);
            this.enlaceConContabilidadToolStripMenuItem2.Text = "Enlace con Contabilidad";
            // 
            // bancos5000ToolStripMenuItem
            // 
            this.bancos5000ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catálogosToolStripMenuItem2,
            this.transaccionalToolStripMenuItem3,
            this.reportesToolStripMenuItem5,
            this.procesosToolStripMenuItem5});
            this.bancos5000ToolStripMenuItem.Name = "bancos5000ToolStripMenuItem";
            this.bancos5000ToolStripMenuItem.Size = new System.Drawing.Size(114, 24);
            this.bancos5000ToolStripMenuItem.Text = "Bancos (5000)";
            // 
            // catálogosToolStripMenuItem2
            // 
            this.catálogosToolStripMenuItem2.Name = "catálogosToolStripMenuItem2";
            this.catálogosToolStripMenuItem2.Size = new System.Drawing.Size(187, 26);
            this.catálogosToolStripMenuItem2.Text = "Catálogos";
            // 
            // transaccionalToolStripMenuItem3
            // 
            this.transaccionalToolStripMenuItem3.Name = "transaccionalToolStripMenuItem3";
            this.transaccionalToolStripMenuItem3.Size = new System.Drawing.Size(187, 26);
            this.transaccionalToolStripMenuItem3.Text = "Transaccionales";
            // 
            // reportesToolStripMenuItem5
            // 
            this.reportesToolStripMenuItem5.Name = "reportesToolStripMenuItem5";
            this.reportesToolStripMenuItem5.Size = new System.Drawing.Size(187, 26);
            this.reportesToolStripMenuItem5.Text = "Reportes";
            // 
            // procesosToolStripMenuItem5
            // 
            this.procesosToolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enlaceConContabilidadToolStripMenuItem3});
            this.procesosToolStripMenuItem5.Name = "procesosToolStripMenuItem5";
            this.procesosToolStripMenuItem5.Size = new System.Drawing.Size(187, 26);
            this.procesosToolStripMenuItem5.Text = "Procesos";
            // 
            // enlaceConContabilidadToolStripMenuItem3
            // 
            this.enlaceConContabilidadToolStripMenuItem3.Name = "enlaceConContabilidadToolStripMenuItem3";
            this.enlaceConContabilidadToolStripMenuItem3.Size = new System.Drawing.Size(245, 26);
            this.enlaceConContabilidadToolStripMenuItem3.Text = "Enlace con Contabilidad";
            // 
            // cxCCxPComprasToolStripMenuItem
            // 
            this.cxCCxPComprasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catálogosToolStripMenuItem3,
            this.transaccionalesToolStripMenuItem2,
            this.reportesToolStripMenuItem4,
            this.procesosToolStripMenuItem4});
            this.cxCCxPComprasToolStripMenuItem.Name = "cxCCxPComprasToolStripMenuItem";
            this.cxCCxPComprasToolStripMenuItem.Size = new System.Drawing.Size(143, 24);
            this.cxCCxPComprasToolStripMenuItem.Text = "CxC, CxP, Compras";
            // 
            // catálogosToolStripMenuItem3
            // 
            this.catálogosToolStripMenuItem3.Name = "catálogosToolStripMenuItem3";
            this.catálogosToolStripMenuItem3.Size = new System.Drawing.Size(187, 26);
            this.catálogosToolStripMenuItem3.Text = "Catálogos";
            // 
            // transaccionalesToolStripMenuItem2
            // 
            this.transaccionalesToolStripMenuItem2.Name = "transaccionalesToolStripMenuItem2";
            this.transaccionalesToolStripMenuItem2.Size = new System.Drawing.Size(187, 26);
            this.transaccionalesToolStripMenuItem2.Text = "Transaccionales";
            // 
            // reportesToolStripMenuItem4
            // 
            this.reportesToolStripMenuItem4.Name = "reportesToolStripMenuItem4";
            this.reportesToolStripMenuItem4.Size = new System.Drawing.Size(187, 26);
            this.reportesToolStripMenuItem4.Text = "Reportes";
            // 
            // procesosToolStripMenuItem4
            // 
            this.procesosToolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enlaceConContabilidadToolStripMenuItem4});
            this.procesosToolStripMenuItem4.Name = "procesosToolStripMenuItem4";
            this.procesosToolStripMenuItem4.Size = new System.Drawing.Size(187, 26);
            this.procesosToolStripMenuItem4.Text = "Procesos";
            // 
            // enlaceConContabilidadToolStripMenuItem4
            // 
            this.enlaceConContabilidadToolStripMenuItem4.Name = "enlaceConContabilidadToolStripMenuItem4";
            this.enlaceConContabilidadToolStripMenuItem4.Size = new System.Drawing.Size(245, 26);
            this.enlaceConContabilidadToolStripMenuItem4.Text = "Enlace con Contabilidad";
            // 
            // cotizacionToolStripMenuItem
            // 
            this.cotizacionToolStripMenuItem.Name = "cotizacionToolStripMenuItem";
            this.cotizacionToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.cotizacionToolStripMenuItem.Text = "Cotizacion";
            this.cotizacionToolStripMenuItem.Click += new System.EventHandler(this.cotizacionToolStripMenuItem_Click);
            // 
            // pedidoToolStripMenuItem
            // 
            this.pedidoToolStripMenuItem.Name = "pedidoToolStripMenuItem";
            this.pedidoToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.pedidoToolStripMenuItem.Text = "Pedido";
            this.pedidoToolStripMenuItem.Click += new System.EventHandler(this.pedidoToolStripMenuItem_Click_1);
            // 
            // facturacionToolStripMenuItem
            // 
            this.facturacionToolStripMenuItem.Name = "facturacionToolStripMenuItem";
            this.facturacionToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
            this.facturacionToolStripMenuItem.Text = "Facturacion";
            this.facturacionToolStripMenuItem.Click += new System.EventHandler(this.facturacionToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1108, 629);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "MDI Hotel San Carlos";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem inventarioYFacturación2000ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catálogoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaccionalToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem entradasYSalidaInventarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trasladoEntreBodegasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem procesosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem enlaceConContabilidadToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem contabilidad4000ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catálogosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem transaccionalesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem procesosToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem enlaceConContabilidadToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bancos5000ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catálogosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem transaccionalToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem procesosToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem enlaceConContabilidadToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem cxCCxPComprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catálogosToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem transaccionalesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem procesosToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem enlaceConContabilidadToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem comisionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoDePreciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actualizarListasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hotelería1000ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaccionalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaccionalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem procesosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enlaceConContabilidadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nóminas3000ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catálogosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaccionalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem procesosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem nuevoEnvioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mantenimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pilotoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unidadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cotizacionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pedidoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facturacionToolStripMenuItem;
    }
}

